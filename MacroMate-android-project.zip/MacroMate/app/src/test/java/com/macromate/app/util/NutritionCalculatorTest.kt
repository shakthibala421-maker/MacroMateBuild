package com.macromate.app.util

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Unit tests for the core scaling formula (spec section 30):
 *     nutrient consumed = nutrient per 100g × quantity / 100
 * Covers the required edge cases: 0g, 1g, 100g, 500g, 1000g, and invalid
 * negative quantity.
 */
class NutritionCalculatorTest {

    // Chicken breast, cooked: 165 kcal / 31 g protein / 0 carbs / 3.6 g fat / 0 fibre per 100g
    private val kcal = 165.0
    private val protein = 31.0
    private val carbs = 0.0
    private val fat = 3.6
    private val fibre = 0.0

    private fun calc(qty: Double) =
        NutritionCalculator.calculate(kcal, protein, carbs, fat, fibre, qty)

    @Test
    fun `0 grams yields all-zero nutrients`() {
        val result = calc(0.0)
        assertEquals(0.0, result.calories, 0.001)
        assertEquals(0.0, result.protein, 0.001)
        assertEquals(0.0, result.fat, 0.001)
    }

    @Test
    fun `1 gram scales down correctly`() {
        val result = calc(1.0)
        assertEquals(1.65, result.calories, 0.01)
        assertEquals(0.31, result.protein, 0.01)
    }

    @Test
    fun `100 grams matches the per-100g values exactly`() {
        val result = calc(100.0)
        assertEquals(165.0, result.calories, 0.001)
        assertEquals(31.0, result.protein, 0.001)
        assertEquals(3.6, result.fat, 0.001)
    }

    @Test
    fun `500 grams scales up correctly (example from spec doubled further)`() {
        val result = calc(500.0)
        assertEquals(825.0, result.calories, 0.01)
        assertEquals(155.0, result.protein, 0.01)
    }

    @Test
    fun `1000 grams scales up by 10x`() {
        val result = calc(1000.0)
        assertEquals(1650.0, result.calories, 0.01)
        assertEquals(310.0, result.protein, 0.01)
    }

    @Test
    fun `200 grams matches the exact spec example for chicken breast`() {
        val result = calc(200.0)
        // Spec section 7 example: 200g chicken breast ~= 330 kcal, 62g protein, 7.2g fat
        assertEquals(330.0, result.calories, 0.01)
        assertEquals(62.0, result.protein, 0.01)
        assertEquals(7.2, result.fat, 0.01)
    }

    @Test
    fun `negative quantity is treated as zero instead of producing negative nutrients`() {
        val result = calc(-50.0)
        assertEquals(0.0, result.calories, 0.001)
        assertEquals(0.0, result.protein, 0.001)
    }
}
