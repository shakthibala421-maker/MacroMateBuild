package com.macromate.app.recipe

import com.macromate.app.data.local.entity.RecipeIngredient
import com.macromate.app.util.NutritionCalculator
import org.junit.Assert.assertEquals
import org.junit.Test

/** Unit tests for recipe total + per-serving math (spec section 30). */
class RecipeMathTest {

    private fun ingredient(kcal: Double, protein: Double, qty: Double) = RecipeIngredient(
        recipeId = 0, foodName = "test", caloriesPer100g = kcal, proteinPer100g = protein,
        carbsPer100g = 0.0, fatPer100g = 0.0, fibrePer100g = 0.0, quantityGrams = qty
    )

    @Test
    fun `recipe totals sum every ingredient correctly`() {
        val ingredients = listOf(
            ingredient(kcal = 130.0, protein = 2.7, qty = 250.0), // rice
            ingredient(kcal = 165.0, protein = 31.0, qty = 150.0) // chicken
        )
        var totalCal = 0.0
        var totalProtein = 0.0
        ingredients.forEach {
            val r = NutritionCalculator.calculate(
                it.caloriesPer100g, it.proteinPer100g, it.carbsPer100g, it.fatPer100g, it.fibrePer100g, it.quantityGrams
            )
            totalCal += r.calories
            totalProtein += r.protein
        }
        assertEquals(130.0 * 2.5 + 165.0 * 1.5, totalCal, 0.5)
        assertEquals(2.7 * 2.5 + 31.0 * 1.5, totalProtein, 0.5)
    }

    @Test
    fun `per-serving divides total evenly and never divides by zero servings`() {
        val total = 800.0
        val servings = 0 // invalid input should still be safely handled
        val safeServings = servings.coerceAtLeast(1)
        assertEquals(800.0, total / safeServings, 0.001)
    }
}
