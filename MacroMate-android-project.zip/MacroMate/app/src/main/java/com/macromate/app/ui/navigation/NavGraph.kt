package com.macromate.app.ui.navigation

sealed class Screen(val route: String) {
    data object Dashboard : Screen("dashboard")
    data object Search : Screen("search")
    data object AddCustomFood : Screen("add_custom_food")
    data object FoodDetail : Screen("food_detail/{foodId}") {
        fun createRoute(foodId: Long) = "food_detail/$foodId"
    }
    data object History : Screen("history")
    data object Statistics : Screen("statistics")
    data object Settings : Screen("settings")
    data object Water : Screen("water")
    data object RecipeBuilder : Screen("recipe_builder")
}
