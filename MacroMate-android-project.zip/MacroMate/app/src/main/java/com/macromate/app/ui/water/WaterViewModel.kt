package com.macromate.app.ui.water

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.macromate.app.data.local.entity.WaterEntry
import com.macromate.app.data.repository.WaterRepository
import com.macromate.app.util.todayIso
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class WaterViewModel(private val waterRepository: WaterRepository) : ViewModel() {
    private val date = todayIso()

    private val _entries = MutableStateFlow<List<WaterEntry>>(emptyList())
    val entries: StateFlow<List<WaterEntry>> = _entries

    init {
        viewModelScope.launch {
            waterRepository.getEntriesForDate(date).collect { _entries.value = it }
        }
    }

    fun addWater(amountMl: Int) {
        viewModelScope.launch { waterRepository.addEntry(WaterEntry(date = date, amountMl = amountMl)) }
    }

    fun totalMl(): Int = _entries.value.sumOf { it.amountMl }

    class Factory(private val waterRepository: WaterRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = WaterViewModel(waterRepository) as T
    }
}
