package com.macromate.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single food item and its nutrition PER 100 GRAMS.
 *
 * All calculations elsewhere in the app (diary, recipes, search results)
 * scale these per-100g values by the quantity the user actually ate.
 * See [com.macromate.app.util.NutritionCalculator].
 */
@Entity(tableName = "foods")
data class Food(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val caloriesPer100g: Double,
    val proteinPer100g: Double,
    val carbsPer100g: Double,
    val fatPer100g: Double,
    val fibrePer100g: Double,
    val defaultServingGrams: Double = 100.0,
    // "local" (bundled/seed data), "custom" (user-entered), "usda" (cached API result)
    val source: String = "local",
    val isCustom: Boolean = false
)
