package com.macromate.app.ui.fooddetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.macromate.app.data.local.entity.DiaryEntry
import com.macromate.app.data.local.entity.Food
import com.macromate.app.data.local.entity.MealType
import com.macromate.app.data.repository.DiaryRepository
import com.macromate.app.util.NutritionCalculator
import com.macromate.app.util.NutritionResult
import com.macromate.app.util.todayIso
import kotlinx.coroutines.launch

class FoodDetailViewModel(private val diaryRepository: DiaryRepository) : ViewModel() {

    /**
     * Applies the app's one scaling formula (per-100g × quantity / 100) and
     * validates the input so a blank, negative, or non-numeric quantity never
     * crashes the screen — it just falls back to 0 nutrients.
     */
    fun calculate(food: Food, quantityGramsText: String): NutritionResult {
        val qty = quantityGramsText.toDoubleOrNull() ?: 0.0
        return NutritionCalculator.calculate(food, qty)
    }

    fun logFood(
        food: Food,
        quantityGrams: Double,
        mealType: MealType,
        result: NutritionResult,
        date: String = todayIso(),
        onLogged: () -> Unit
    ) {
        viewModelScope.launch {
            diaryRepository.logEntry(
                DiaryEntry(
                    foodId = food.id,
                    foodName = food.name,
                    date = date,
                    mealType = mealType,
                    quantityGrams = quantityGrams,
                    calories = result.calories,
                    protein = result.protein,
                    carbs = result.carbs,
                    fat = result.fat,
                    fibre = result.fibre
                )
            )
            onLogged()
        }
    }

    class Factory(private val diaryRepository: DiaryRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            FoodDetailViewModel(diaryRepository) as T
    }
}
