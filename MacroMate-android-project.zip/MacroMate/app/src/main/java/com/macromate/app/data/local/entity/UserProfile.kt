package com.macromate.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ActivityLevel { SEDENTARY, LIGHT, MODERATE, ACTIVE, VERY_ACTIVE }
enum class FitnessGoal { WEIGHT_LOSS, MAINTENANCE, MUSCLE_GAIN }
enum class Gender { MALE, FEMALE, OTHER, PREFER_NOT_TO_SAY }

/**
 * Single-row table (id is always 1) holding the user's optional profile info.
 * Every field is nullable / optional — the app never forces the user to fill
 * these in before it's usable.
 */
@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String? = null,
    val age: Int? = null,
    val heightCm: Double? = null,
    val weightKg: Double? = null,
    val gender: Gender? = null,
    val activityLevel: ActivityLevel = ActivityLevel.MODERATE,
    val goal: FitnessGoal = FitnessGoal.MUSCLE_GAIN,
    val muscleGainModeEnabled: Boolean = true
)
