package com.macromate.app.ui.fooddetail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.macromate.app.data.local.entity.Food
import com.macromate.app.data.local.entity.MealType
import com.macromate.app.ui.components.SourceTag

/**
 * "How much did you eat?" screen (spec section 7).
 * Defaults to 100g, recalculates live as the user types a new quantity,
 * and lets them pick which meal to log it under before saving.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodDetailScreen(
    food: Food,
    viewModel: FoodDetailViewModel,
    onLogged: () -> Unit,
    onBack: () -> Unit
) {
    var quantityText by remember { mutableStateOf("100") }
    var selectedMeal by remember { mutableStateOf(MealType.BREAKFAST) }
    var mealMenuExpanded by remember { mutableStateOf(false) }

    val result = remember(quantityText) { viewModel.calculate(food, quantityText) }
    val quantity = quantityText.toDoubleOrNull() ?: 0.0
    val isValidQuantity = quantity >= 0.0 && quantityText.isNotBlank()

    Scaffold(topBar = { TopAppBar(title = { Text(food.name) }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(20.dp)) {
            SourceTag(food.source)
            Spacer(Modifier.height(16.dp))

            Text("Per 100 g", style = MaterialTheme.typography.titleMedium)
            NutrientLine("Calories", food.caloriesPer100g, "kcal")
            NutrientLine("Protein", food.proteinPer100g, "g")
            NutrientLine("Carbs", food.carbsPer100g, "g")
            NutrientLine("Fat", food.fatPer100g, "g")
            NutrientLine("Fibre", food.fibrePer100g, "g")

            Spacer(Modifier.height(24.dp))
            Text("How much did you eat?", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = quantityText,
                onValueChange = { quantityText = it },
                label = { Text("Quantity (grams)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = !isValidQuantity,
                supportingText = { if (!isValidQuantity) Text("Enter a valid, non-negative amount") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))
            Text("For $quantityText g", style = MaterialTheme.typography.titleMedium)
            NutrientLine("Calories", result.calories, "kcal")
            NutrientLine("Protein", result.protein, "g")
            NutrientLine("Carbs", result.carbs, "g")
            NutrientLine("Fat", result.fat, "g")
            NutrientLine("Fibre", result.fibre, "g")

            Spacer(Modifier.height(20.dp))
            ExposedDropdownMenuBox(expanded = mealMenuExpanded, onExpandedChange = { mealMenuExpanded = it }) {
                OutlinedTextField(
                    value = selectedMeal.name.lowercase().replaceFirstChar { it.uppercase() },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Meal") },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = mealMenuExpanded, onDismissRequest = { mealMenuExpanded = false }) {
                    MealType.values().forEach { meal ->
                        DropdownMenuItem(
                            text = { Text(meal.name.lowercase().replaceFirstChar { it.uppercase() }) },
                            onClick = { selectedMeal = meal; mealMenuExpanded = false }
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    viewModel.logFood(food, quantity, selectedMeal, result, onLogged = onLogged)
                },
                enabled = isValidQuantity,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add to Diary")
            }
        }
    }
}

@Composable
private fun NutrientLine(label: String, value: Double, unit: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, modifier = Modifier.weight(1f))
        Text("$value $unit", fontWeight = FontWeight.Medium)
    }
}
