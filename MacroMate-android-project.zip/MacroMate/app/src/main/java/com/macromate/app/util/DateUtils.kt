package com.macromate.app.util

import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val ISO_FORMAT: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE

/** Today's date as "yyyy-MM-dd" — the format used for every date column in Room. */
fun todayIso(): String = LocalDate.now().format(ISO_FORMAT)

fun LocalDate.toIso(): String = format(ISO_FORMAT)

fun String.toLocalDate(): LocalDate = LocalDate.parse(this, ISO_FORMAT)

fun String.toDisplayDate(): String =
    toLocalDate().format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy"))
