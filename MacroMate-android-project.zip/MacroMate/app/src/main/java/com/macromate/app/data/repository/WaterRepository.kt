package com.macromate.app.data.repository

import com.macromate.app.data.local.dao.WaterDao
import com.macromate.app.data.local.entity.WaterEntry
import kotlinx.coroutines.flow.Flow

class WaterRepository(private val waterDao: WaterDao) {
    fun getEntriesForDate(date: String): Flow<List<WaterEntry>> = waterDao.getEntriesForDate(date)
    suspend fun addEntry(entry: WaterEntry): Long = waterDao.insert(entry)
    suspend fun deleteEntry(entry: WaterEntry) = waterDao.delete(entry)
}
