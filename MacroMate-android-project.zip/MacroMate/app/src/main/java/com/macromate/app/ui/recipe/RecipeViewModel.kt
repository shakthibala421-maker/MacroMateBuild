package com.macromate.app.ui.recipe

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.macromate.app.data.local.dao.RecipeWithIngredients
import com.macromate.app.data.local.entity.Recipe
import com.macromate.app.data.local.entity.RecipeIngredient
import com.macromate.app.data.repository.RecipeRepository
import com.macromate.app.util.NutritionCalculator
import com.macromate.app.util.NutritionResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** Recipe Builder (spec section 27): add ingredients, get totals, divide by servings. */
class RecipeViewModel(private val recipeRepository: RecipeRepository) : ViewModel() {

    private val _recipes = MutableStateFlow<List<RecipeWithIngredients>>(emptyList())
    val recipes: StateFlow<List<RecipeWithIngredients>> = _recipes

    init {
        viewModelScope.launch { recipeRepository.getAllRecipes().collect { _recipes.value = it } }
    }

    fun totalNutrition(ingredients: List<RecipeIngredient>): NutritionResult {
        var cal = 0.0; var pro = 0.0; var carb = 0.0; var fat = 0.0; var fibre = 0.0
        ingredients.forEach {
            val r = NutritionCalculator.calculate(
                it.caloriesPer100g, it.proteinPer100g, it.carbsPer100g, it.fatPer100g, it.fibrePer100g, it.quantityGrams
            )
            cal += r.calories; pro += r.protein; carb += r.carbs; fat += r.fat; fibre += r.fibre
        }
        return NutritionResult(cal, pro, carb, fat, fibre)
    }

    fun perServing(total: NutritionResult, servings: Int): NutritionResult {
        val s = servings.coerceAtLeast(1)
        return NutritionResult(total.calories / s, total.protein / s, total.carbs / s, total.fat / s, total.fibre / s)
    }

    fun saveRecipe(name: String, servings: Int, ingredients: List<RecipeIngredient>, onSaved: () -> Unit) {
        viewModelScope.launch {
            recipeRepository.saveRecipe(Recipe(name = name, servings = servings), ingredients)
            onSaved()
        }
    }

    class Factory(private val recipeRepository: RecipeRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = RecipeViewModel(recipeRepository) as T
    }
}
