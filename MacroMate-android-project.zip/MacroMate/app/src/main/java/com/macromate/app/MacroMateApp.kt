package com.macromate.app

import android.app.Application
import com.macromate.app.data.local.AppDatabase
import com.macromate.app.data.repository.DiaryRepository
import com.macromate.app.data.repository.FoodRepository
import com.macromate.app.data.repository.RecipeRepository
import com.macromate.app.data.repository.UserRepository
import com.macromate.app.data.repository.WaterRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Application class: a tiny hand-rolled "service locator" that builds the
 * database and repositories once and hands the same instances to every
 * screen's ViewModel. This is intentionally simple (no Hilt/Dagger) to keep
 * the project approachable for a beginner, while still keeping the
 * architecture modular — each screen only depends on the repository
 * interfaces it needs.
 */
class MacroMateApp : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var foodRepository: FoodRepository
        private set
    lateinit var diaryRepository: DiaryRepository
        private set
    lateinit var userRepository: UserRepository
        private set
    lateinit var waterRepository: WaterRepository
        private set
    lateinit var recipeRepository: RecipeRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        foodRepository = FoodRepository(database.foodDao())
        diaryRepository = DiaryRepository(database.diaryDao())
        userRepository = UserRepository(database.userProfileDao(), database.dailyGoalsDao())
        waterRepository = WaterRepository(database.waterDao())
        recipeRepository = RecipeRepository(database.recipeDao())

        // Belt-and-suspenders: make sure the seed foods exist even if the
        // Room onCreate callback ever races with the first read.
        CoroutineScope(Dispatchers.IO + SupervisorJob()).launch {
            foodRepository.ensureSeeded()
        }
    }
}
