package com.macromate.app.ui.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.macromate.app.data.local.entity.Food
import com.macromate.app.ui.components.SourceTag
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: SearchViewModel,
    onFoodSelected: (Food) -> Unit,
    onAddCustomFood: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Search Foods") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAddCustomFood, text = { Text("Custom Food") }, icon = {
                Icon(Icons.Filled.Add, contentDescription = null)
            })
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::onQueryChanged,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Try \"chick\", \"dosa\", \"rice\"...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))

            if (state.query.isNotBlank() && state.localResults.isEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("No match in the local database.")
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = viewModel::searchUsda, enabled = !state.isSearchingUsda) {
                            Text(if (state.isSearchingUsda) "Searching USDA..." else "Search USDA FoodData Central")
                        }
                        state.usdaError?.let {
                            Spacer(Modifier.height(8.dp))
                            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            LazyColumn {
                items(state.localResults) { food ->
                    FoodResultRow(food, onClick = { onFoodSelected(food) })
                }
                items(state.usdaResults) { food ->
                    FoodResultRow(food, onClick = { onFoodSelected(food) })
                }
            }
        }
    }
}

@Composable
private fun FoodResultRow(food: Food, onClick: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        onClick = onClick
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(food.name, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "${food.caloriesPer100g.roundToInt()} kcal • ${food.proteinPer100g}g protein • " +
                        "${food.carbsPer100g}g carbs • ${food.fatPer100g}g fat • ${food.fibrePer100g}g fibre (per 100g)",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(6.dp))
                SourceTag(food.source)
            }
            IconButton(onClick = onClick) { Icon(Icons.Filled.Add, contentDescription = "Add") }
        }
    }
}
