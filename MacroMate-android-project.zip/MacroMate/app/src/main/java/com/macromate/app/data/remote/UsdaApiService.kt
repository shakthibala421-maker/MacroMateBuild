package com.macromate.app.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

/** Retrofit interface for the public USDA FoodData Central API.
 *  Docs: https://fdc.nal.usda.gov/api-spec/fdc_api.html */
interface UsdaApiService {
    @GET("v1/foods/search")
    suspend fun searchFoods(
        @Query("query") query: String,
        @Query("api_key") apiKey: String,
        @Query("pageSize") pageSize: Int = 10
    ): UsdaSearchResponse
}
