package com.macromate.app.ui.water

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

/** Water intake tracking — spec section 20. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WaterScreen(viewModel: WaterViewModel) {
    val entries by viewModel.entries.collectAsState()
    var customAmount by remember { mutableStateOf("") }

    Scaffold(topBar = { TopAppBar(title = { Text("Water Intake") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(20.dp)) {
            Text("Today's water intake", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text("${entries.sumOf { it.amountMl }} ml", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(20.dp))

            Row {
                listOf(250, 500, 750, 1000).forEach { amount ->
                    OutlinedButton(
                        onClick = { viewModel.addWater(amount) },
                        modifier = Modifier.padding(end = 8.dp)
                    ) { Text("${amount} ml") }
                }
            }

            Spacer(Modifier.height(20.dp))
            Row {
                OutlinedTextField(
                    value = customAmount,
                    onValueChange = { customAmount = it },
                    label = { Text("Custom amount (ml)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        customAmount.toIntOrNull()?.takeIf { it > 0 }?.let {
                            viewModel.addWater(it)
                            customAmount = ""
                        }
                    },
                    modifier = Modifier.align(androidx.compose.ui.Alignment.CenterVertically)
                ) { Text("Add") }
            }
        }
    }
}
