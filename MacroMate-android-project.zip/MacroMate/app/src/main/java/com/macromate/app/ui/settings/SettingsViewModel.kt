package com.macromate.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.macromate.app.data.local.entity.DailyGoals
import com.macromate.app.data.local.entity.UserProfile
import com.macromate.app.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class SettingsUiState(
    val profile: UserProfile = UserProfile(),
    val goals: DailyGoals = DailyGoals()
)

class SettingsViewModel(private val userRepository: UserRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState

    init {
        viewModelScope.launch {
            combine(userRepository.getProfile(), userRepository.getGoals()) { profile, goals ->
                SettingsUiState(profile ?: UserProfile(), goals ?: DailyGoals())
            }.collect { _uiState.value = it }
        }
    }

    fun saveProfile(profile: UserProfile) {
        viewModelScope.launch { userRepository.saveProfile(profile) }
    }

    fun saveGoals(goals: DailyGoals) {
        viewModelScope.launch { userRepository.saveGoals(goals) }
    }

    /** BMI is only a general screening number, not a diagnosis — surfaced as a plain
     *  number + category in the UI, always alongside that disclaimer. */
    fun calculateBmi(heightCm: Double?, weightKg: Double?): Pair<Double, String>? {
        if (heightCm == null || weightKg == null || heightCm <= 0 || weightKg <= 0) return null
        val heightM = heightCm / 100.0
        val bmi = weightKg / (heightM * heightM)
        val category = when {
            bmi < 18.5 -> "Underweight"
            bmi < 25.0 -> "Normal"
            bmi < 30.0 -> "Overweight"
            else -> "Obese"
        }
        return bmi to category
    }

    class Factory(private val userRepository: UserRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            SettingsViewModel(userRepository) as T
    }
}
