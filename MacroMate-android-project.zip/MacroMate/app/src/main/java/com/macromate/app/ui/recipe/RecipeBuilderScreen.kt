package com.macromate.app.ui.recipe

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.macromate.app.data.local.entity.RecipeIngredient
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeBuilderScreen(viewModel: RecipeViewModel, onSaved: () -> Unit) {
    var recipeName by remember { mutableStateOf("") }
    var servings by remember { mutableStateOf("4") }
    var ingredients by remember { mutableStateOf(listOf<RecipeIngredient>()) }
    var showAddIngredient by remember { mutableStateOf(false) }

    val total = remember(ingredients) { viewModel.totalNutrition(ingredients) }
    val perServing = remember(total, servings) { viewModel.perServing(total, servings.toIntOrNull() ?: 1) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Recipe Builder") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddIngredient = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add ingredient")
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            OutlinedTextField(
                recipeName, { recipeName = it },
                label = { Text("Recipe name (e.g. Chicken Rice)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                servings, { servings = it },
                label = { Text("Servings") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )

            Spacer(Modifier.height(12.dp))
            Text("Ingredients", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.weight(1f)) {
                items(ingredients) { ing ->
                    ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text("${ing.foodName} — ${ing.quantityGrams.roundToInt()} g", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Total recipe: ${total.calories.roundToInt()} kcal, P ${total.protein.roundToInt()}g, " +
                        "C ${total.carbs.roundToInt()}g, F ${total.fat.roundToInt()}g, Fibre ${total.fibre.roundToInt()}g")
                    Spacer(Modifier.height(4.dp))
                    Text("Per serving: ${perServing.calories.roundToInt()} kcal, P ${perServing.protein.roundToInt()}g, " +
                        "C ${perServing.carbs.roundToInt()}g, F ${perServing.fat.roundToInt()}g, Fibre ${perServing.fibre.roundToInt()}g",
                        fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    if (recipeName.isNotBlank() && ingredients.isNotEmpty()) {
                        viewModel.saveRecipe(recipeName, servings.toIntOrNull() ?: 1, ingredients, onSaved)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = recipeName.isNotBlank() && ingredients.isNotEmpty()
            ) { Text("Save Recipe") }
        }
    }

    if (showAddIngredient) {
        AddIngredientDialog(
            onDismiss = { showAddIngredient = false },
            onAdd = { ingredient -> ingredients = ingredients + ingredient; showAddIngredient = false }
        )
    }
}

@Composable
private fun AddIngredientDialog(onDismiss: () -> Unit, onAdd: (RecipeIngredient) -> Unit) {
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var carbs by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    var fibre by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Ingredient") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(qty, { qty = it }, label = { Text("Quantity (g)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(kcal, { kcal = it }, label = { Text("Calories / 100g") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(protein, { protein = it }, label = { Text("Protein / 100g") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(carbs, { carbs = it }, label = { Text("Carbs / 100g") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(fat, { fat = it }, label = { Text("Fat / 100g") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(fibre, { fibre = it }, label = { Text("Fibre / 100g") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onAdd(
                    RecipeIngredient(
                        recipeId = 0,
                        foodName = name.ifBlank { "Ingredient" },
                        caloriesPer100g = kcal.toDoubleOrNull() ?: 0.0,
                        proteinPer100g = protein.toDoubleOrNull() ?: 0.0,
                        carbsPer100g = carbs.toDoubleOrNull() ?: 0.0,
                        fatPer100g = fat.toDoubleOrNull() ?: 0.0,
                        fibrePer100g = fibre.toDoubleOrNull() ?: 0.0,
                        quantityGrams = qty.toDoubleOrNull() ?: 0.0
                    )
                )
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
