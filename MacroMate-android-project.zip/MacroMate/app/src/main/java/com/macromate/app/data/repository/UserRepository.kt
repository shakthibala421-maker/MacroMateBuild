package com.macromate.app.data.repository

import com.macromate.app.data.local.dao.DailyGoalsDao
import com.macromate.app.data.local.dao.UserProfileDao
import com.macromate.app.data.local.entity.DailyGoals
import com.macromate.app.data.local.entity.UserProfile
import kotlinx.coroutines.flow.Flow

class UserRepository(
    private val profileDao: UserProfileDao,
    private val goalsDao: DailyGoalsDao
) {
    fun getProfile(): Flow<UserProfile?> = profileDao.getProfile()
    suspend fun saveProfile(profile: UserProfile) = profileDao.upsertProfile(profile)

    fun getGoals(): Flow<DailyGoals?> = goalsDao.getGoals()
    suspend fun saveGoals(goals: DailyGoals) = goalsDao.upsertGoals(goals)
}
