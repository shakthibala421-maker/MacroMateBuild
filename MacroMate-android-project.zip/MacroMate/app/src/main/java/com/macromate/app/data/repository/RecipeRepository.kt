package com.macromate.app.data.repository

import com.macromate.app.data.local.dao.RecipeDao
import com.macromate.app.data.local.dao.RecipeWithIngredients
import com.macromate.app.data.local.entity.Recipe
import com.macromate.app.data.local.entity.RecipeIngredient
import kotlinx.coroutines.flow.Flow

class RecipeRepository(private val recipeDao: RecipeDao) {
    fun getAllRecipes(): Flow<List<RecipeWithIngredients>> = recipeDao.getAllRecipes()

    suspend fun saveRecipe(recipe: Recipe, ingredients: List<RecipeIngredient>): Long {
        val recipeId = recipeDao.insertRecipe(recipe)
        recipeDao.insertIngredients(ingredients.map { it.copy(recipeId = recipeId) })
        return recipeId
    }

    suspend fun deleteRecipe(recipe: Recipe) = recipeDao.deleteRecipe(recipe)
}
