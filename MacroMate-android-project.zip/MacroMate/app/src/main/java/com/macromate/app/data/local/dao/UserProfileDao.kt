package com.macromate.app.data.local.dao

import androidx.room.*
import com.macromate.app.data.local.entity.DailyGoals
import com.macromate.app.data.local.entity.UserProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: UserProfile)
}

@Dao
interface DailyGoalsDao {
    @Query("SELECT * FROM daily_goals WHERE id = 1 LIMIT 1")
    fun getGoals(): Flow<DailyGoals?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGoals(goals: DailyGoals)
}
