package com.macromate.app.ui.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.macromate.app.util.toDisplayDate
import com.macromate.app.util.toIso
import kotlin.math.roundToInt

/** Calendar/history screen: pick a previous date, see totals + all foods logged that day. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(viewModel: HistoryViewModel) {
    val state by viewModel.uiState.collectAsState()
    val recentDates = remember {
        (0..29).map { java.time.LocalDate.now().minusDays(it.toLong()).toIso() }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("History") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LazyRow(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                items(recentDates) { date ->
                    FilterChip(
                        selected = date == state.selectedDate,
                        onClick = { viewModel.loadDate(date) },
                        label = { Text(date.toDisplayDate().substringBefore(",")) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            val totalCalories = state.entries.sumOf { it.calories }
            val totalProtein = state.entries.sumOf { it.protein }
            val totalCarbs = state.entries.sumOf { it.carbs }
            val totalFat = state.entries.sumOf { it.fat }
            val totalFibre = state.entries.sumOf { it.fibre }

            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(state.selectedDate.toDisplayDate(), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("${totalCalories.roundToInt()} kcal  •  P ${totalProtein.roundToInt()}g  •  " +
                        "C ${totalCarbs.roundToInt()}g  •  F ${totalFat.roundToInt()}g  •  Fibre ${totalFibre.roundToInt()}g")
                }
            }

            if (state.entries.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(24.dp)) {
                    Text("No foods logged on this date.")
                }
            } else {
                LazyColumn(Modifier.padding(horizontal = 16.dp)) {
                    items(state.entries) { entry ->
                        ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(entry.foodName, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${entry.quantityGrams.roundToInt()} g • ${entry.calories.roundToInt()} kcal • " +
                                        "${entry.mealType.name.lowercase().replaceFirstChar { it.uppercase() }}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
