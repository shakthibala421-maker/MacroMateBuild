package com.macromate.app.data.repository

import com.macromate.app.data.local.dao.DiaryDao
import com.macromate.app.data.local.entity.DiaryEntry
import kotlinx.coroutines.flow.Flow

class DiaryRepository(private val diaryDao: DiaryDao) {
    fun getEntriesForDate(date: String): Flow<List<DiaryEntry>> = diaryDao.getEntriesForDate(date)

    suspend fun getEntriesBetween(startDate: String, endDate: String): List<DiaryEntry> =
        diaryDao.getEntriesBetween(startDate, endDate)

    suspend fun logEntry(entry: DiaryEntry): Long = diaryDao.insert(entry)

    suspend fun updateEntry(entry: DiaryEntry) = diaryDao.update(entry)

    suspend fun deleteEntry(entry: DiaryEntry) = diaryDao.delete(entry)

    suspend fun getAllLoggedDates(): List<String> = diaryDao.getAllLoggedDates()
}
