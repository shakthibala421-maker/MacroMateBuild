package com.macromate.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.macromate.app.data.local.dao.DailyGoalsDao
import com.macromate.app.data.local.dao.DiaryDao
import com.macromate.app.data.local.dao.FoodDao
import com.macromate.app.data.local.dao.RecipeDao
import com.macromate.app.data.local.dao.UserProfileDao
import com.macromate.app.data.local.dao.WaterDao
import com.macromate.app.data.local.entity.DailyGoals
import com.macromate.app.data.local.entity.DiaryEntry
import com.macromate.app.data.local.entity.Food
import com.macromate.app.data.local.entity.Recipe
import com.macromate.app.data.local.entity.RecipeIngredient
import com.macromate.app.data.local.entity.UserProfile
import com.macromate.app.data.local.entity.WaterEntry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Food::class,
        DiaryEntry::class,
        UserProfile::class,
        DailyGoals::class,
        WaterEntry::class,
        Recipe::class,
        RecipeIngredient::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun foodDao(): FoodDao
    abstract fun diaryDao(): DiaryDao
    abstract fun userProfileDao(): UserProfileDao
    abstract fun dailyGoalsDao(): DailyGoalsDao
    abstract fun waterDao(): WaterDao
    abstract fun recipeDao(): RecipeDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "macromate.db"
                )
                    .addCallback(SeedCallback(context))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    /** Pre-populates the local food table the first time the database is created. */
    private class SeedCallback(private val context: Context) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            CoroutineScope(Dispatchers.IO).launch {
                getInstance(context).foodDao().insertAll(FoodSeedData.seedFoods)
            }
        }
    }
}
