package com.macromate.app.data.local

import com.macromate.app.data.local.entity.Food

/**
 * Starter local food database: common Indian foods + widely-eaten international foods.
 *
 * All values are APPROXIMATE, per 100 grams (edible/cooked portion unless noted),
 * sourced from typical published nutrition references (USDA / IFCT-style figures).
 * Real-world values vary by brand, recipe, and cooking method — this is why the
 * app labels these as "Local (approx.)" rather than claiming lab-exact precision,
 * and why custom-food and recipe-builder entry exists for anything more specific.
 *
 * NOTE: This is a starter set covering every food category the spec asked for.
 * Add more rows here any time — this is just data, so extending the database
 * later ("add paneer tikka", "add jowar roti", etc.) is a one-line change.
 */
object FoodSeedData {

    private fun f(
        name: String, category: String,
        kcal: Double, protein: Double, carbs: Double, fat: Double, fibre: Double,
        servingGrams: Double = 100.0
    ) = Food(
        name = name, category = category,
        caloriesPer100g = kcal, proteinPer100g = protein, carbsPer100g = carbs,
        fatPer100g = fat, fibrePer100g = fibre, defaultServingGrams = servingGrams,
        source = "local", isCustom = false
    )

    val seedFoods: List<Food> = listOf(
        // ---- Rice & grains ----
        f("White Rice, cooked", "Grains", 130.0, 2.7, 28.2, 0.3, 0.4),
        f("Brown Rice, cooked", "Grains", 123.0, 2.7, 25.6, 1.0, 1.8),
        f("Basmati Rice, cooked", "Grains", 121.0, 2.5, 25.0, 0.4, 0.6),
        f("Oats, dry", "Grains", 389.0, 16.9, 66.3, 6.9, 10.6, 40.0),
        f("Wheat Flour (Atta)", "Grains", 340.0, 12.0, 71.0, 1.5, 11.0),
        f("Chapati (whole wheat, plain)", "Grains", 297.0, 8.7, 55.0, 4.9, 5.0, 40.0),
        f("Roti (tawa, no oil)", "Grains", 264.0, 8.0, 52.0, 2.0, 5.0, 40.0),

        // ---- South Indian foods ----
        f("Idli", "South Indian", 132.0, 3.9, 26.0, 0.5, 1.4, 40.0),
        f("Dosa, plain", "South Indian", 168.0, 3.9, 28.0, 3.7, 1.2, 60.0),
        f("Masala Dosa", "South Indian", 210.0, 4.5, 28.0, 9.0, 1.8, 120.0),
        f("Pongal (ven pongal)", "South Indian", 155.0, 4.2, 24.0, 4.5, 1.0, 150.0),
        f("Upma", "South Indian", 180.0, 4.0, 26.0, 6.5, 1.5, 150.0),
        f("Vada (medu vada)", "South Indian", 280.0, 8.0, 28.0, 15.0, 3.0, 40.0),
        f("Sambar", "South Indian", 90.0, 4.0, 12.0, 2.5, 3.0, 150.0),
        f("Rasam", "South Indian", 45.0, 1.8, 7.0, 1.0, 1.0, 150.0),
        f("Curd Rice", "South Indian", 120.0, 3.5, 18.0, 3.0, 0.5, 150.0),
        f("Lemon Rice", "South Indian", 160.0, 3.0, 24.0, 6.0, 1.0, 150.0),

        // ---- Protein foods ----
        f("Whole Egg, boiled", "Protein", 155.0, 13.0, 1.1, 11.0, 0.0, 50.0),
        f("Egg White, cooked", "Protein", 52.0, 10.9, 0.7, 0.2, 0.0, 33.0),
        f("Chicken Breast, cooked", "Protein", 165.0, 31.0, 0.0, 3.6, 0.0),
        f("Chicken Thigh, cooked", "Protein", 209.0, 26.0, 0.0, 10.9, 0.0),
        f("Fish (Rohu), cooked", "Protein", 120.0, 21.0, 0.0, 3.5, 0.0),
        f("Tuna, canned in water", "Protein", 116.0, 26.0, 0.0, 0.8, 0.0),
        f("Paneer", "Protein", 265.0, 18.3, 1.2, 20.8, 0.0),
        f("Tofu, firm", "Protein", 76.0, 8.0, 1.9, 4.8, 0.3),
        f("Soy Chunks (dry)", "Protein", 345.0, 52.0, 33.0, 0.5, 13.0, 30.0),
        f("Milk, whole", "Protein", 61.0, 3.2, 4.8, 3.3, 0.0),
        f("Curd (Dahi), plain", "Protein", 60.0, 3.5, 4.7, 3.3, 0.0),
        f("Greek Yogurt, plain", "Protein", 59.0, 10.0, 3.6, 0.4, 0.0),

        // ---- Pulses ----
        f("Toor Dal, cooked", "Pulses", 121.0, 7.0, 20.0, 1.5, 5.5, 150.0),
        f("Moong Dal, cooked", "Pulses", 105.0, 7.0, 17.0, 0.7, 5.0, 150.0),
        f("Chana Dal, cooked", "Pulses", 164.0, 9.0, 27.0, 2.6, 7.0, 150.0),
        f("Chickpeas (Chole), cooked", "Pulses", 164.0, 8.9, 27.4, 2.6, 7.6, 150.0),
        f("Rajma (Kidney Beans), cooked", "Pulses", 127.0, 8.7, 22.8, 0.5, 6.4, 150.0),
        f("Green Gram, sprouted", "Pulses", 30.0, 3.0, 5.9, 0.2, 1.8, 100.0),

        // ---- Fruits ----
        f("Banana", "Fruits", 89.0, 1.1, 22.8, 0.3, 2.6, 120.0),
        f("Apple", "Fruits", 52.0, 0.3, 13.8, 0.2, 2.4, 150.0),
        f("Orange", "Fruits", 47.0, 0.9, 11.8, 0.1, 2.4, 150.0),
        f("Mango", "Fruits", 60.0, 0.8, 15.0, 0.4, 1.6, 150.0),
        f("Grapes", "Fruits", 69.0, 0.7, 18.1, 0.2, 0.9, 100.0),
        f("Papaya", "Fruits", 43.0, 0.5, 10.8, 0.3, 1.7, 150.0),
        f("Watermelon", "Fruits", 30.0, 0.6, 7.6, 0.2, 0.4, 200.0),
        f("Guava", "Fruits", 68.0, 2.6, 14.3, 1.0, 5.4, 100.0),

        // ---- Nuts ----
        f("Peanut", "Nuts", 567.0, 25.8, 16.1, 49.2, 8.5, 30.0),
        f("Almond", "Nuts", 579.0, 21.2, 21.6, 49.9, 12.5, 30.0),
        f("Cashew", "Nuts", 553.0, 18.2, 30.2, 43.9, 3.3, 30.0),
        f("Walnut", "Nuts", 654.0, 15.2, 13.7, 65.2, 6.7, 30.0),

        // ---- Vegetables ----
        f("Potato, boiled", "Vegetables", 87.0, 1.9, 20.1, 0.1, 1.8, 150.0),
        f("Sweet Potato, boiled", "Vegetables", 86.0, 1.6, 20.1, 0.1, 3.0, 150.0),
        f("Tomato", "Vegetables", 18.0, 0.9, 3.9, 0.2, 1.2, 100.0),
        f("Onion", "Vegetables", 40.0, 1.1, 9.3, 0.1, 1.7, 100.0),
        f("Carrot", "Vegetables", 41.0, 0.9, 9.6, 0.2, 2.8, 100.0),
        f("Beans (green/French)", "Vegetables", 31.0, 1.8, 7.1, 0.2, 3.4, 100.0),
        f("Spinach", "Vegetables", 23.0, 2.9, 3.6, 0.4, 2.2, 100.0),
        f("Broccoli", "Vegetables", 34.0, 2.8, 6.6, 0.4, 2.6, 100.0),
        f("Cauliflower", "Vegetables", 25.0, 1.9, 5.0, 0.3, 2.0, 100.0)
    )
}
