package com.macromate.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Single-row table (id is always 1) holding the user's current daily targets.
 * Defaults match the app's default use case (muscle gain) but are fully
 * user-editable from the Settings screen — never hard-coded at runtime.
 */
@Entity(tableName = "daily_goals")
data class DailyGoals(
    @PrimaryKey val id: Int = 1,
    val calorieGoal: Int = 2500,
    val proteinGoalGrams: Int = 120,
    val carbsGoalGrams: Int = 280,
    val fatGoalGrams: Int = 80,
    val fibreGoalGrams: Int = 30,
    val waterGoalMl: Int = 2500
)
