package com.macromate.app.data.local.dao

import androidx.room.*
import com.macromate.app.data.local.entity.WaterEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface WaterDao {
    @Query("SELECT * FROM water_entries WHERE date = :date ORDER BY loggedAtEpochMs ASC")
    fun getEntriesForDate(date: String): Flow<List<WaterEntry>>

    @Insert
    suspend fun insert(entry: WaterEntry): Long

    @Delete
    suspend fun delete(entry: WaterEntry)
}
