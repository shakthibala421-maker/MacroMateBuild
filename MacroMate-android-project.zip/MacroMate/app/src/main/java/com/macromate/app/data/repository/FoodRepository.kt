package com.macromate.app.data.repository

import com.macromate.app.BuildConfig
import com.macromate.app.data.local.dao.FoodDao
import com.macromate.app.data.local.entity.Food
import com.macromate.app.data.remote.RetrofitClient
import com.macromate.app.data.remote.UsdaNutrientIds
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

sealed class FoodSearchResult {
    data class Success(val foods: List<Food>, val fromNetwork: Boolean) : FoodSearchResult()
    data class Error(val message: String) : FoodSearchResult()
}

/**
 * Search strategy (see spec section 9):
 *  1. Search the local Room database first (works fully offline).
 *  2. If that returns nothing, and we're allowed to hit the network, fall back
 *     to the USDA FoodData Central API and label those results clearly as
 *     coming from USDA rather than the local approximate database.
 */
class FoodRepository(private val foodDao: FoodDao) {

    fun searchLocal(query: String): Flow<List<Food>> = foodDao.search(query)

    fun getAllFoods(): Flow<List<Food>> = foodDao.getAll()

    fun getCustomFoods(): Flow<List<Food>> = foodDao.getCustomFoods()

    suspend fun getFoodById(id: Long): Food? = foodDao.getById(id)

    suspend fun saveCustomFood(food: Food): Long = foodDao.insert(food.copy(isCustom = true, source = "custom"))

    suspend fun updateFood(food: Food) = foodDao.update(food)

    suspend fun deleteFood(food: Food) = foodDao.delete(food)

    /**
     * Live USDA search, used only when the local database has no match and the
     * device has connectivity. Never throws — API/network failures are caught
     * and turned into a friendly [FoodSearchResult.Error] so the app never
     * crashes just because USDA is unreachable.
     */
    suspend fun searchUsda(query: String): FoodSearchResult = withContext(Dispatchers.IO) {
        try {
            val response = RetrofitClient.usdaApi.searchFoods(query, BuildConfig.USDA_API_KEY)
            val foods = response.foods.map { item ->
                fun nutrientValue(id: Int): Double =
                    item.foodNutrients.firstOrNull { it.nutrientId == id }?.value ?: 0.0

                Food(
                    name = item.description,
                    category = "USDA",
                    caloriesPer100g = nutrientValue(UsdaNutrientIds.ENERGY_KCAL),
                    proteinPer100g = nutrientValue(UsdaNutrientIds.PROTEIN),
                    carbsPer100g = nutrientValue(UsdaNutrientIds.CARBS),
                    fatPer100g = nutrientValue(UsdaNutrientIds.FAT),
                    fibrePer100g = nutrientValue(UsdaNutrientIds.FIBRE),
                    source = "usda"
                )
            }
            FoodSearchResult.Success(foods, fromNetwork = true)
        } catch (e: Exception) {
            FoodSearchResult.Error(e.message ?: "Couldn't reach USDA FoodData Central. Check your connection.")
        }
    }

    suspend fun ensureSeeded() {
        // Safety net: if seeding via the Room callback ever races or fails, this
        // lets callers (e.g. MacroMateApp.onCreate) verify and retry once.
        if (foodDao.count() == 0) {
            foodDao.insertAll(com.macromate.app.data.local.FoodSeedData.seedFoods)
        }
    }
}
