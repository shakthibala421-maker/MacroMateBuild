package com.macromate.app.ui.history

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/** Weekly/30-day/90-day averages (spec section 13). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatisticsScreen(viewModel: HistoryViewModel) {
    var rangeDays by remember { mutableStateOf(7) }
    var stats by remember { mutableStateOf<HistoryViewModel.DayStats?>(null) }

    LaunchedEffect(rangeDays) {
        stats = viewModel.computeStats(rangeDays)
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Statistics") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Row {
                listOf(7 to "7 days", 30 to "30 days", 90 to "90 days").forEach { (days, label) ->
                    FilterChip(
                        selected = rangeDays == days,
                        onClick = { rangeDays = days },
                        label = { Text(label) },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            stats?.let { s ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Averages per day (${s.daysWithData} day(s) with data)", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        StatRow("Calories", s.avgCalories, "kcal")
                        StatRow("Protein", s.avgProtein, "g")
                        StatRow("Carbs", s.avgCarbs, "g")
                        StatRow("Fat", s.avgFat, "g")
                        StatRow("Fibre", s.avgFibre, "g")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: Double, unit: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, modifier = Modifier.weight(1f))
        Text("${value.roundToInt()} $unit", fontWeight = FontWeight.Medium)
    }
}
