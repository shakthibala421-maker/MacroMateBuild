package com.macromate.app.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.macromate.app.data.local.entity.ActivityLevel
import com.macromate.app.data.local.entity.DailyGoals
import com.macromate.app.data.local.entity.FitnessGoal
import com.macromate.app.data.local.entity.UserProfile

/** Profile / Goals / BMI / Muscle Gain Mode — spec sections 14, 15, 16.
 *  Every personal field is optional; the user is never blocked from using
 *  the app without filling these in. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val state by viewModel.uiState.collectAsState()

    var name by remember(state.profile) { mutableStateOf(state.profile.name ?: "") }
    var age by remember(state.profile) { mutableStateOf(state.profile.age?.toString() ?: "") }
    var height by remember(state.profile) { mutableStateOf(state.profile.heightCm?.toString() ?: "") }
    var weight by remember(state.profile) { mutableStateOf(state.profile.weightKg?.toString() ?: "") }
    var goal by remember(state.profile) { mutableStateOf(state.profile.goal) }
    var activity by remember(state.profile) { mutableStateOf(state.profile.activityLevel) }
    var muscleGainMode by remember(state.profile) { mutableStateOf(state.profile.muscleGainModeEnabled) }

    var calorieGoal by remember(state.goals) { mutableStateOf(state.goals.calorieGoal.toString()) }
    var proteinGoal by remember(state.goals) { mutableStateOf(state.goals.proteinGoalGrams.toString()) }
    var carbsGoal by remember(state.goals) { mutableStateOf(state.goals.carbsGoalGrams.toString()) }
    var fatGoal by remember(state.goals) { mutableStateOf(state.goals.fatGoalGrams.toString()) }
    var fibreGoal by remember(state.goals) { mutableStateOf(state.goals.fibreGoalGrams.toString()) }

    val bmi = viewModel.calculateBmi(height.toDoubleOrNull(), weight.toDoubleOrNull())

    Scaffold(topBar = { TopAppBar(title = { Text("Profile & Goals") }) }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())
        ) {
            Text("Profile (all optional)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                OutlinedTextField(
                    age, { age = it }, label = { Text("Age") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f).padding(end = 6.dp)
                )
                OutlinedTextField(
                    height, { height = it }, label = { Text("Height (cm)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f).padding(start = 6.dp)
                )
            }
            OutlinedTextField(
                weight, { weight = it }, label = { Text("Weight (kg)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )

            bmi?.let { (value, category) ->
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("BMI: ${"%.1f".format(value)} ($category)", fontWeight = FontWeight.SemiBold)
                        Text(
                            "BMI is only a general screening measure, not a medical diagnosis.",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Goal", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(top = 8.dp)) {
                FitnessGoal.values().forEach { g ->
                    FilterChip(
                        selected = goal == g,
                        onClick = { goal = g },
                        label = { Text(g.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("Activity Level", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(top = 8.dp)) {
                ActivityLevel.values().forEach { a ->
                    FilterChip(
                        selected = activity == a,
                        onClick = { activity = a },
                        label = { Text(a.name.take(4)) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Switch(checked = muscleGainMode, onCheckedChange = { muscleGainMode = it })
                Spacer(Modifier.width(8.dp))
                Text("Muscle Gain Mode")
            }

            Spacer(Modifier.height(24.dp))
            Text("Daily Goals (editable any time)", style = MaterialTheme.typography.titleMedium)
            GoalField("Calorie goal (kcal)", calorieGoal) { calorieGoal = it }
            GoalField("Protein goal (g)", proteinGoal) { proteinGoal = it }
            GoalField("Carbs goal (g)", carbsGoal) { carbsGoal = it }
            GoalField("Fat goal (g)", fatGoal) { fatGoal = it }
            GoalField("Fibre goal (g)", fibreGoal) { fibreGoal = it }

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    viewModel.saveProfile(
                        UserProfile(
                            name = name.ifBlank { null },
                            age = age.toIntOrNull(),
                            heightCm = height.toDoubleOrNull(),
                            weightKg = weight.toDoubleOrNull(),
                            gender = state.profile.gender,
                            activityLevel = activity,
                            goal = goal,
                            muscleGainModeEnabled = muscleGainMode
                        )
                    )
                    viewModel.saveGoals(
                        DailyGoals(
                            calorieGoal = calorieGoal.toIntOrNull() ?: 2500,
                            proteinGoalGrams = proteinGoal.toIntOrNull() ?: 120,
                            carbsGoalGrams = carbsGoal.toIntOrNull() ?: 280,
                            fatGoalGrams = fatGoal.toIntOrNull() ?: 80,
                            fibreGoalGrams = fibreGoal.toIntOrNull() ?: 30,
                            waterGoalMl = state.goals.waterGoalMl
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save")
            }

            if (muscleGainMode) {
                Spacer(Modifier.height(20.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Muscle Gain Mode", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("Daily calorie target: ${state.goals.calorieGoal} kcal")
                        Text("Daily protein target: ${state.goals.proteinGoalGrams} g")
                        state.profile.weightKg?.let { Text("Current weight: $it kg") }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "This app tracks numbers only — it doesn't give medical advice. " +
                                "Talk to a doctor or nutritionist for personalized guidance.",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GoalField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    )
}
