package com.macromate.app.data.remote

import com.google.gson.annotations.SerializedName

/** Minimal subset of the USDA FoodData Central /foods/search response we actually use.
 *  Full spec: https://fdc.nal.usda.gov/api-spec/fdc_api.html */
data class UsdaSearchResponse(
    @SerializedName("foods") val foods: List<UsdaFoodItem> = emptyList()
)

data class UsdaFoodItem(
    @SerializedName("fdcId") val fdcId: Long,
    @SerializedName("description") val description: String,
    @SerializedName("foodNutrients") val foodNutrients: List<UsdaNutrient> = emptyList()
)

data class UsdaNutrient(
    @SerializedName("nutrientName") val nutrientName: String?,
    @SerializedName("nutrientId") val nutrientId: Int?,
    @SerializedName("value") val value: Double?
)

/** USDA nutrient IDs for the 5 macros we track (per FDC nutrient reference tables). */
object UsdaNutrientIds {
    const val ENERGY_KCAL = 1008
    const val PROTEIN = 1003
    const val CARBS = 1005
    const val FAT = 1004
    const val FIBRE = 1079
}
