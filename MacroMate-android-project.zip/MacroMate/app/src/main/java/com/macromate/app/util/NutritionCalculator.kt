package com.macromate.app.util

import com.macromate.app.data.local.entity.Food
import kotlin.math.round

/** Nutrient totals for whatever quantity was actually eaten. */
data class NutritionResult(
    val calories: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val fibre: Double
)

/**
 * Core scaling formula used everywhere in the app:
 *     nutrient consumed = nutrient per 100g × quantity / 100
 *
 * Centralizing it here (instead of repeating the math in every screen) means
 * there's exactly one place to unit-test and exactly one place to fix if the
 * formula ever needs to change.
 */
object NutritionCalculator {

    fun calculate(food: Food, quantityGrams: Double): NutritionResult =
        calculate(
            caloriesPer100g = food.caloriesPer100g,
            proteinPer100g = food.proteinPer100g,
            carbsPer100g = food.carbsPer100g,
            fatPer100g = food.fatPer100g,
            fibrePer100g = food.fibrePer100g,
            quantityGrams = quantityGrams
        )

    fun calculate(
        caloriesPer100g: Double,
        proteinPer100g: Double,
        carbsPer100g: Double,
        fatPer100g: Double,
        fibrePer100g: Double,
        quantityGrams: Double
    ): NutritionResult {
        // Guard against invalid/negative input rather than returning nonsense or crashing.
        val safeQty = quantityGrams.coerceAtLeast(0.0)
        val factor = safeQty / 100.0
        return NutritionResult(
            calories = round1(caloriesPer100g * factor),
            protein = round1(proteinPer100g * factor),
            carbs = round1(carbsPer100g * factor),
            fat = round1(fatPer100g * factor),
            fibre = round1(fibrePer100g * factor)
        )
    }

    private fun round1(value: Double): Double = round(value * 10.0) / 10.0
}
