package com.macromate.app.data.local.dao

import androidx.room.*
import com.macromate.app.data.local.entity.Food
import kotlinx.coroutines.flow.Flow

@Dao
interface FoodDao {

    // Case-insensitive partial-name search across local + custom foods.
    // "%" wildcards make it match anywhere in the name, e.g. "chick" -> "Chicken breast".
    @Query("SELECT * FROM foods WHERE name LIKE '%' || :query || '%' COLLATE NOCASE ORDER BY name ASC")
    fun search(query: String): Flow<List<Food>>

    @Query("SELECT * FROM foods ORDER BY name ASC")
    fun getAll(): Flow<List<Food>>

    @Query("SELECT * FROM foods WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Food?

    @Query("SELECT * FROM foods WHERE isCustom = 1 ORDER BY name ASC")
    fun getCustomFoods(): Flow<List<Food>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(foods: List<Food>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(food: Food): Long

    @Update
    suspend fun update(food: Food)

    @Delete
    suspend fun delete(food: Food)

    @Query("SELECT COUNT(*) FROM foods")
    suspend fun count(): Int
}
