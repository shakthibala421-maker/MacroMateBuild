package com.macromate.app.ui.theme

import androidx.compose.ui.graphics.Color

// Fitness-app palette: green = energy/nutrition, warm accent for calories.
val GreenPrimary = Color(0xFF2E7D32)
val GreenPrimaryDark = Color(0xFF81C784)
val CalorieOrange = Color(0xFFFF7043)
val ProteinBlue = Color(0xFF42A5F5)
val CarbsAmber = Color(0xFFFFCA28)
val FatPurple = Color(0xFFAB47BC)
val FibreTeal = Color(0xFF26A69A)
val SurfaceLight = Color(0xFFF7FAF7)
val SurfaceDark = Color(0xFF10140F)
