package com.macromate.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class MealType { BREAKFAST, LUNCH, SNACKS, DINNER, OTHER }

/**
 * One logged food entry: "user ate X grams of food Y at meal Z on date D".
 * Nutrition for the entry is snapshotted at log time (caloriesAtLog, etc.)
 * so that editing the underlying Food later doesn't silently rewrite history.
 */
@Entity(
    tableName = "diary_entries",
    foreignKeys = [
        ForeignKey(
            entity = Food::class,
            parentColumns = ["id"],
            childColumns = ["foodId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("foodId"), Index("date")]
)
data class DiaryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val foodId: Long?,
    val foodName: String, // snapshotted in case foodId is later deleted
    val date: String, // ISO format yyyy-MM-dd
    val mealType: MealType,
    val quantityGrams: Double,
    val calories: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val fibre: Double,
    val loggedAtEpochMs: Long = System.currentTimeMillis()
)
