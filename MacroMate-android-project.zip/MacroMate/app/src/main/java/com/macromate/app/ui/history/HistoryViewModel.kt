package com.macromate.app.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.macromate.app.data.local.entity.DiaryEntry
import com.macromate.app.data.repository.DiaryRepository
import com.macromate.app.util.todayIso
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class HistoryUiState(
    val selectedDate: String = todayIso(),
    val entries: List<DiaryEntry> = emptyList(),
    val loggedDates: List<String> = emptyList()
)

/** Backs the History/Calendar screen (spec section 12) and the Weekly
 *  Statistics screen (spec section 13), since both read from the same
 *  date-range diary data. */
class HistoryViewModel(private val diaryRepository: DiaryRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(HistoryUiState())
    val uiState: StateFlow<HistoryUiState> = _uiState

    init {
        loadDate(todayIso())
        viewModelScope.launch {
            val dates = diaryRepository.getAllLoggedDates()
            _uiState.value = _uiState.value.copy(loggedDates = dates)
        }
    }

    fun loadDate(date: String) {
        viewModelScope.launch {
            diaryRepository.getEntriesForDate(date).collect { entries ->
                _uiState.value = _uiState.value.copy(selectedDate = date, entries = entries)
            }
        }
    }

    data class DayStats(
        val avgCalories: Double, val avgProtein: Double, val avgCarbs: Double,
        val avgFat: Double, val avgFibre: Double, val daysWithData: Int
    )

    /** Computes weekly/monthly/90-day averages for the Statistics screen. */
    suspend fun computeStats(days: Int): DayStats {
        val end = todayIso()
        val start = java.time.LocalDate.now().minusDays((days - 1).toLong()).toString()
        val entries = diaryRepository.getEntriesBetween(start, end)
        val byDate = entries.groupBy { it.date }
        val dayCount = byDate.keys.size.coerceAtLeast(1)
        return DayStats(
            avgCalories = entries.sumOf { it.calories } / dayCount,
            avgProtein = entries.sumOf { it.protein } / dayCount,
            avgCarbs = entries.sumOf { it.carbs } / dayCount,
            avgFat = entries.sumOf { it.fat } / dayCount,
            avgFibre = entries.sumOf { it.fibre } / dayCount,
            daysWithData = byDate.keys.size
        )
    }

    class Factory(private val diaryRepository: DiaryRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            HistoryViewModel(diaryRepository) as T
    }
}
