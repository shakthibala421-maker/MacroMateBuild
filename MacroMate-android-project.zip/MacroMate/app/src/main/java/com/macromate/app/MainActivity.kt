package com.macromate.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.macromate.app.data.local.entity.Food
import com.macromate.app.ui.customfood.AddCustomFoodScreen
import com.macromate.app.ui.dashboard.DashboardScreen
import com.macromate.app.ui.dashboard.DashboardViewModel
import com.macromate.app.ui.fooddetail.FoodDetailScreen
import com.macromate.app.ui.fooddetail.FoodDetailViewModel
import com.macromate.app.ui.history.HistoryScreen
import com.macromate.app.ui.history.HistoryViewModel
import com.macromate.app.ui.history.StatisticsScreen
import com.macromate.app.ui.navigation.Screen
import com.macromate.app.ui.recipe.RecipeBuilderScreen
import com.macromate.app.ui.recipe.RecipeViewModel
import com.macromate.app.ui.search.SearchScreen
import com.macromate.app.ui.search.SearchViewModel
import com.macromate.app.ui.settings.SettingsScreen
import com.macromate.app.ui.settings.SettingsViewModel
import com.macromate.app.ui.theme.MacroMateTheme
import com.macromate.app.ui.water.WaterScreen
import com.macromate.app.ui.water.WaterViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as MacroMateApp
        setContent {
            MacroMateTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MacroMateApp(app)
                }
            }
        }
    }
}

private data class BottomTab(val screen: Screen, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun MacroMateApp(app: MacroMateApp) {
    val navController = rememberNavController()
    var showQuickAdd by remember { mutableStateOf(false) }
    // Holds the food the user just picked from Search, so the FoodDetail
    // screen can read it directly instead of re-parceling a whole object
    // through nav arguments.
    var selectedFood by remember { mutableStateOf<Food?>(null) }

    val tabs = listOf(
        BottomTab(Screen.Dashboard, "Home", Icons.Filled.Home),
        BottomTab(Screen.Search, "Food", Icons.Filled.Search),
        BottomTab(Screen.History, "History", Icons.Filled.History),
        BottomTab(Screen.Settings, "Profile", Icons.Filled.Person)
    )

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.screen.route,
                        onClick = {
                            navController.navigate(tab.screen.route) {
                                popUpTo(Screen.Dashboard.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showQuickAdd = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Quick add")
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            NavHost(navController = navController, startDestination = Screen.Dashboard.route) {
                composable(Screen.Dashboard.route) {
                    val vm: DashboardViewModel = viewModel(
                        factory = DashboardViewModel.Factory(app.diaryRepository, app.userRepository)
                    )
                    DashboardScreen(vm, onEditEntry = { /* Edit reuses Add-to-diary flow via FoodDetail in a full build */ })
                }
                composable(Screen.Search.route) {
                    val vm: SearchViewModel = viewModel(factory = SearchViewModel.Factory(app.foodRepository))
                    SearchScreen(
                        viewModel = vm,
                        onFoodSelected = { food ->
                            selectedFood = food
                            navController.navigate(Screen.FoodDetail.createRoute(food.id))
                        },
                        onAddCustomFood = { navController.navigate(Screen.AddCustomFood.route) }
                    )
                }
                composable(Screen.AddCustomFood.route) {
                    AddCustomFoodScreen(
                        foodRepository = app.foodRepository,
                        onSaved = { navController.popBackStack() },
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(Screen.FoodDetail.route) {
                    val food = selectedFood
                    if (food != null) {
                        val vm: FoodDetailViewModel = viewModel(
                            factory = FoodDetailViewModel.Factory(app.diaryRepository)
                        )
                        FoodDetailScreen(
                            food = food,
                            viewModel = vm,
                            onLogged = { navController.popBackStack(Screen.Dashboard.route, false) },
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
                composable(Screen.History.route) {
                    val vm: HistoryViewModel = viewModel(factory = HistoryViewModel.Factory(app.diaryRepository))
                    HistoryScreen(vm)
                }
                composable(Screen.Statistics.route) {
                    val vm: HistoryViewModel = viewModel(factory = HistoryViewModel.Factory(app.diaryRepository))
                    StatisticsScreen(vm)
                }
                composable(Screen.Settings.route) {
                    val vm: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory(app.userRepository))
                    SettingsScreen(vm)
                }
                composable(Screen.Water.route) {
                    val vm: WaterViewModel = viewModel(factory = WaterViewModel.Factory(app.waterRepository))
                    WaterScreen(vm)
                }
                composable(Screen.RecipeBuilder.route) {
                    val vm: RecipeViewModel = viewModel(factory = RecipeViewModel.Factory(app.recipeRepository))
                    RecipeBuilderScreen(vm, onSaved = { navController.popBackStack() })
                }
            }

            if (showQuickAdd) {
                QuickAddSheet(
                    onDismiss = { showQuickAdd = false },
                    onSearchFood = { showQuickAdd = false; navController.navigate(Screen.Search.route) },
                    onCustomFood = { showQuickAdd = false; navController.navigate(Screen.AddCustomFood.route) },
                    onWater = { showQuickAdd = false; navController.navigate(Screen.Water.route) },
                    onRecipe = { showQuickAdd = false; navController.navigate(Screen.RecipeBuilder.route) },
                    onStatistics = { showQuickAdd = false; navController.navigate(Screen.Statistics.route) }
                )
            }
        }
    }
}

/** Central Quick Add bottom sheet — spec section 19. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickAddSheet(
    onDismiss: () -> Unit,
    onSearchFood: () -> Unit,
    onCustomFood: () -> Unit,
    onWater: () -> Unit,
    onRecipe: () -> Unit,
    onStatistics: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Quick Add", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            QuickAddRow(Icons.Filled.Search, "Search Food", onSearchFood)
            QuickAddRow(Icons.Filled.Add, "Custom Food", onCustomFood)
            QuickAddRow(Icons.Filled.WaterDrop, "Water", onWater)
            QuickAddRow(Icons.Filled.Add, "Recipe Builder", onRecipe)
            QuickAddRow(Icons.Filled.History, "Statistics", onStatistics)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun QuickAddRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(label) },
        leadingContent = { Icon(icon, contentDescription = null) },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
