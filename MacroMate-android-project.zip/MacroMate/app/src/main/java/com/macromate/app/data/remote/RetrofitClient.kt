package com.macromate.app.data.remote

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Builds the Retrofit client used to talk to USDA FoodData Central.
 *
 * IMPORTANT (see also README "USDA API Key" section): the key here comes from
 * BuildConfig.USDA_API_KEY, which Gradle fills in from gradle.properties /
 * local.properties at build time — it is never hard-coded in source. For a
 * real published app, don't ship a personal API key inside the APK at all:
 * route this call through your own backend server that holds the key, and
 * have the app call your backend instead of calling USDA directly.
 */
object RetrofitClient {
    private const val BASE_URL = "https://api.nal.usda.gov/fdc/"

    val usdaApi: UsdaApiService by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(UsdaApiService::class.java)
    }
}
