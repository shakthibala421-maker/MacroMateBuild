package com.macromate.app.data.local.dao

import androidx.room.*
import com.macromate.app.data.local.entity.DiaryEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface DiaryDao {

    @Query("SELECT * FROM diary_entries WHERE date = :date ORDER BY loggedAtEpochMs ASC")
    fun getEntriesForDate(date: String): Flow<List<DiaryEntry>>

    @Query("SELECT * FROM diary_entries WHERE date BETWEEN :startDate AND :endDate ORDER BY date ASC")
    suspend fun getEntriesBetween(startDate: String, endDate: String): List<DiaryEntry>

    @Insert
    suspend fun insert(entry: DiaryEntry): Long

    @Update
    suspend fun update(entry: DiaryEntry)

    @Delete
    suspend fun delete(entry: DiaryEntry)

    @Query("DELETE FROM diary_entries WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT DISTINCT date FROM diary_entries ORDER BY date DESC")
    suspend fun getAllLoggedDates(): List<String>
}
