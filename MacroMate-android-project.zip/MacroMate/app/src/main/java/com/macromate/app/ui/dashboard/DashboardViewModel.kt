package com.macromate.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.macromate.app.data.local.entity.DailyGoals
import com.macromate.app.data.local.entity.DiaryEntry
import com.macromate.app.data.local.entity.MealType
import com.macromate.app.data.repository.DiaryRepository
import com.macromate.app.data.repository.UserRepository
import com.macromate.app.util.todayIso
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class DashboardUiState(
    val date: String = todayIso(),
    val entries: List<DiaryEntry> = emptyList(),
    val goals: DailyGoals = DailyGoals(),
    val totalCalories: Double = 0.0,
    val totalProtein: Double = 0.0,
    val totalCarbs: Double = 0.0,
    val totalFat: Double = 0.0,
    val totalFibre: Double = 0.0
)

class DashboardViewModel(
    private val diaryRepository: DiaryRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState

    init {
        val date = todayIso()
        viewModelScope.launch {
            combine(
                diaryRepository.getEntriesForDate(date),
                userRepository.getGoals()
            ) { entries, goals ->
                DashboardUiState(
                    date = date,
                    entries = entries,
                    goals = goals ?: DailyGoals(),
                    totalCalories = entries.sumOf { it.calories },
                    totalProtein = entries.sumOf { it.protein },
                    totalCarbs = entries.sumOf { it.carbs },
                    totalFat = entries.sumOf { it.fat },
                    totalFibre = entries.sumOf { it.fibre }
                )
            }.collect { _uiState.value = it }
        }
    }

    fun entriesByMeal(): Map<MealType, List<DiaryEntry>> =
        _uiState.value.entries.groupBy { it.mealType }

    fun deleteEntry(entry: DiaryEntry) {
        viewModelScope.launch { diaryRepository.deleteEntry(entry) }
    }

    class Factory(
        private val diaryRepository: DiaryRepository,
        private val userRepository: UserRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            DashboardViewModel(diaryRepository, userRepository) as T
    }
}
