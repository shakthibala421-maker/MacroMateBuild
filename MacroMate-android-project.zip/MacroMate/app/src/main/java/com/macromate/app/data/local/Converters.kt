package com.macromate.app.data.local

import androidx.room.TypeConverter
import com.macromate.app.data.local.entity.ActivityLevel
import com.macromate.app.data.local.entity.FitnessGoal
import com.macromate.app.data.local.entity.Gender
import com.macromate.app.data.local.entity.MealType

/** Room can't store enums directly, so these convert them to/from plain strings. */
class Converters {
    @TypeConverter
    fun fromMealType(value: MealType): String = value.name
    @TypeConverter
    fun toMealType(value: String): MealType = MealType.valueOf(value)

    @TypeConverter
    fun fromActivityLevel(value: ActivityLevel): String = value.name
    @TypeConverter
    fun toActivityLevel(value: String): ActivityLevel = ActivityLevel.valueOf(value)

    @TypeConverter
    fun fromFitnessGoal(value: FitnessGoal): String = value.name
    @TypeConverter
    fun toFitnessGoal(value: String): FitnessGoal = FitnessGoal.valueOf(value)

    @TypeConverter
    fun fromGender(value: Gender?): String? = value?.name
    @TypeConverter
    fun toGender(value: String?): Gender? = value?.let { Gender.valueOf(it) }
}
