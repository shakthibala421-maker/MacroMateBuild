package com.macromate.app.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.macromate.app.data.local.entity.DiaryEntry
import com.macromate.app.data.local.entity.MealType
import com.macromate.app.ui.components.NutrientCard
import com.macromate.app.ui.theme.CalorieOrange
import com.macromate.app.ui.theme.CarbsAmber
import com.macromate.app.ui.theme.FatPurple
import com.macromate.app.ui.theme.FibreTeal
import com.macromate.app.ui.theme.ProteinBlue
import com.macromate.app.util.toDisplayDate
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onEditEntry: (DiaryEntry) -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val mealGroups = remember(state.entries) { state.entries.groupBy { it.mealType } }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("MacroMate", fontWeight = FontWeight.Bold)
                    Text(state.date.toDisplayDate(), style = MaterialTheme.typography.labelMedium)
                }
            })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            item {
                Text("Today's Nutrition", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
            }
            item {
                Row(Modifier.fillMaxWidth()) {
                    NutrientCard(
                        emoji = "\uD83D\uDD25", label = "Calories",
                        consumed = state.totalCalories, goal = state.goals.calorieGoal.toDouble(),
                        unit = "kcal", color = CalorieOrange,
                        modifier = Modifier.weight(1f).padding(end = 6.dp)
                    )
                    NutrientCard(
                        emoji = "\uD83D\uDCAA", label = "Protein",
                        consumed = state.totalProtein, goal = state.goals.proteinGoalGrams.toDouble(),
                        unit = "g", color = ProteinBlue,
                        modifier = Modifier.weight(1f).padding(start = 6.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    NutrientCard(
                        emoji = "\uD83C\uDF5E", label = "Carbs",
                        consumed = state.totalCarbs, goal = state.goals.carbsGoalGrams.toDouble(),
                        unit = "g", color = CarbsAmber,
                        modifier = Modifier.weight(1f).padding(end = 6.dp)
                    )
                    NutrientCard(
                        emoji = "\uD83E\uDD51", label = "Fat",
                        consumed = state.totalFat, goal = state.goals.fatGoalGrams.toDouble(),
                        unit = "g", color = FatPurple,
                        modifier = Modifier.weight(1f).padding(start = 6.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                NutrientCard(
                    emoji = "\uD83C\uDF3E", label = "Fibre",
                    consumed = state.totalFibre, goal = state.goals.fibreGoalGrams.toDouble(),
                    unit = "g", color = FibreTeal,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(20.dp))
                Text("Today's Meals", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
            }

            val order = listOf(MealType.BREAKFAST, MealType.LUNCH, MealType.SNACKS, MealType.DINNER, MealType.OTHER)
            order.forEach { meal ->
                val entries = mealGroups[meal].orEmpty()
                if (entries.isNotEmpty()) {
                    item {
                        Text(
                            meal.name.lowercase().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                    }
                    items(entries) { entry ->
                        DiaryEntryRow(
                            entry = entry,
                            onEdit = { onEditEntry(entry) },
                            onDelete = { viewModel.deleteEntry(entry) }
                        )
                    }
                }
            }

            if (state.entries.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 40.dp)) {
                        Text(
                            "No food logged yet today. Tap the + button to add your first meal.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@Composable
private fun DiaryEntryRow(entry: DiaryEntry, onEdit: () -> Unit, onDelete: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(entry.foodName, fontWeight = FontWeight.SemiBold)
                Text(
                    "${entry.quantityGrams.roundToInt()} g  •  ${entry.calories.roundToInt()} kcal",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "P ${entry.protein.roundToInt()}g  C ${entry.carbs.roundToInt()}g  " +
                        "F ${entry.fat.roundToInt()}g  Fibre ${entry.fibre.roundToInt()}g",
                    style = MaterialTheme.typography.labelMedium
                )
            }
            IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
        }
    }
}
