package com.macromate.app.ui.customfood

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.macromate.app.data.local.entity.Food
import com.macromate.app.data.repository.FoodRepository
import kotlinx.coroutines.launch

/**
 * "Add Custom Food" screen (spec section 10) — also doubles as the manual
 * nutrition-entry path for packaged foods and failed barcode lookups
 * (spec sections 9 and 21): the user types in whatever the product label says.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCustomFoodScreen(
    foodRepository: FoodRepository,
    onSaved: () -> Unit,
    onBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var servingGrams by remember { mutableStateOf("100") }
    var calories by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var carbs by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    var fibre by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Custom") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(topBar = { TopAppBar(title = { Text("Add Custom Food") }) }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())
        ) {
            Text(
                "Enter the nutrition info exactly as printed on the product label, or your own recipe's numbers per 100 g.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(16.dp))

            LabeledField("Food name", name) { name = it }
            LabeledField("Category", category) { category = it }
            LabeledField("Serving size (g)", servingGrams, KeyboardType.Number) { servingGrams = it }
            LabeledField("Calories (per 100 g)", calories, KeyboardType.Number) { calories = it }
            LabeledField("Protein (g per 100 g)", protein, KeyboardType.Number) { protein = it }
            LabeledField("Carbohydrates (g per 100 g)", carbs, KeyboardType.Number) { carbs = it }
            LabeledField("Fat (g per 100 g)", fat, KeyboardType.Number) { fat = it }
            LabeledField("Fibre (g per 100 g)", fibre, KeyboardType.Number) { fibre = it }

            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val kcal = calories.toDoubleOrNull()
                    val p = protein.toDoubleOrNull()
                    val c = carbs.toDoubleOrNull()
                    val fa = fat.toDoubleOrNull()
                    val fi = fibre.toDoubleOrNull()
                    val serving = servingGrams.toDoubleOrNull() ?: 100.0
                    when {
                        name.isBlank() -> error = "Please enter a food name."
                        kcal == null || p == null || c == null || fa == null || fi == null ->
                            error = "Please enter valid numbers for every nutrition field."
                        kcal < 0 || p < 0 || c < 0 || fa < 0 || fi < 0 ->
                            error = "Nutrition values can't be negative."
                        else -> {
                            error = null
                            scope.launch {
                                foodRepository.saveCustomFood(
                                    Food(
                                        name = name.trim(),
                                        category = category.ifBlank { "Custom" },
                                        caloriesPer100g = kcal,
                                        proteinPer100g = p,
                                        carbsPer100g = c,
                                        fatPer100g = fa,
                                        fibrePer100g = fi,
                                        defaultServingGrams = serving
                                    )
                                )
                                onSaved()
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Custom Food")
            }
        }
    }
}

@Composable
private fun LabeledField(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        singleLine = true
    )
}
