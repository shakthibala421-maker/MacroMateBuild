package com.macromate.app.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.macromate.app.data.local.entity.Food
import com.macromate.app.data.repository.FoodRepository
import com.macromate.app.data.repository.FoodSearchResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class SearchUiState(
    val query: String = "",
    val localResults: List<Food> = emptyList(),
    val usdaResults: List<Food> = emptyList(),
    val isSearchingUsda: Boolean = false,
    val usdaError: String? = null
)

class SearchViewModel(private val foodRepository: FoodRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState

    private var localSearchJob: Job? = null

    fun onQueryChanged(query: String) {
        _uiState.value = _uiState.value.copy(query = query, usdaResults = emptyList(), usdaError = null)
        localSearchJob?.cancel()
        if (query.isBlank()) {
            _uiState.value = _uiState.value.copy(localResults = emptyList())
            return
        }
        localSearchJob = viewModelScope.launch {
            foodRepository.searchLocal(query).collect { results ->
                _uiState.value = _uiState.value.copy(localResults = results)
            }
        }
    }

    /** Called when the user explicitly asks to also check USDA (e.g. local search was empty). */
    fun searchUsda() {
        val query = _uiState.value.query
        if (query.isBlank()) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSearchingUsda = true, usdaError = null)
            when (val result = foodRepository.searchUsda(query)) {
                is FoodSearchResult.Success ->
                    _uiState.value = _uiState.value.copy(usdaResults = result.foods, isSearchingUsda = false)
                is FoodSearchResult.Error ->
                    _uiState.value = _uiState.value.copy(usdaError = result.message, isSearchingUsda = false)
            }
        }
    }

    class Factory(private val foodRepository: FoodRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            SearchViewModel(foodRepository) as T
    }
}
