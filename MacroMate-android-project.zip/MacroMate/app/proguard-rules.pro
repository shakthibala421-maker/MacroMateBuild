# Keep Room entities/DAOs
-keep class com.macromate.app.data.local.entity.** { *; }
-keep class com.macromate.app.data.remote.** { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**
