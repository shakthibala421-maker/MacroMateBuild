# MacroMate — Calorie & Macro Tracker

An offline-first Android calorie/macro tracker focused on Indian foods, with
international food support, built with Kotlin + Jetpack Compose + Material 3 +
Room + MVVM.

## What's implemented in this build

- **Dashboard**: today's calories/protein/carbs/fat cards with progress bars,
  fibre tracker, meals grouped by Breakfast/Lunch/Snacks/Dinner with edit/delete.
- **Food search**: case-insensitive, partial-match local search ("chick" →
  Chicken breast/thigh), with a USDA FoodData Central fallback when nothing
  local matches, clearly labeled by source ("Local (approx.)" vs "USDA (live)").
- **Quantity calculator**: enter grams, live-recalculates calories/protein/
  carbs/fat/fibre using `nutrient × quantity / 100`, defaults to 100g.
- **Starter food database**: ~55 Indian + international foods across grains,
  South Indian dishes, protein foods, pulses, fruits, nuts, and vegetables
  (`FoodSeedData.kt` — just add more `Food(...)` rows to extend it).
- **Custom food / manual entry**: for packaged foods or your own recipes —
  stored in Room, same as any other food.
- **Recipe builder**: add multiple ingredients with quantities, get totals and
  per-serving nutrition.
- **History**: pick any of the last 30 days and see everything logged that day.
- **Statistics**: 7/30/90-day averages for calories, protein, carbs, fat, fibre.
- **Profile & Goals**: name/age/height/weight/gender/activity/goal (all
  optional), BMI with a screening-only disclaimer, editable calorie/protein/
  carb/fat/fibre goals (defaults: 2500 kcal, 120g protein — user-editable, not
  hard-coded), Muscle Gain Mode summary card.
- **Water tracking**: 250/500/750/1000ml quick-add + custom amount.
- **Quick Add** floating button: Search Food, Custom Food, Water, Recipe
  Builder, Statistics.
- **Room database**: Food, DiaryEntry, UserProfile, DailyGoals, WaterEntry,
  Recipe, RecipeIngredient tables with foreign keys/indexes.
- **Unit tests**: nutrition scaling formula (0g/1g/100g/500g/1000g/negative
  input) and recipe total/per-serving math.

## What's scaffolded but needs your finishing touch

- **Barcode scanning** (spec §21): not wired up in this build. To add it,
  bring in CameraX + ML Kit Barcode Scanning, and on a successful scan call
  `foodRepository` the same way `AddCustomFoodScreen` does — if the barcode
  isn't found in a product database, fall back to the existing manual-entry
  form (already built) rather than inventing numbers.
- **Edit existing diary entries**: delete is fully wired; "edit" currently
  reopens nothing (empty callback in `MainActivity.kt`) — the simplest next
  step is to route it through `FoodDetailScreen` pre-filled with the entry's
  saved quantity.
- **App icon**: a simple vector placeholder (leaf/flame mark) is included
  instead of designed PNG/SVG artwork — swap `ic_launcher_foreground.xml` for
  real branding whenever you're ready.

## Project structure

```
MacroMate/
  app/
    src/main/java/com/macromate/app/
      MainActivity.kt          - Compose NavHost, bottom nav, Quick Add sheet
      MacroMateApp.kt           - Application class / simple service locator
      data/
        local/                 - Room entities, DAOs, AppDatabase, seed data
        remote/                - USDA FoodData Central Retrofit API
        repository/            - One repository per feature area
      ui/
        dashboard/ search/ fooddetail/ history/ settings/
        customfood/ recipe/ water/ components/ theme/ navigation/
      util/                    - NutritionCalculator, date helpers
    src/test/java/...          - Unit tests
  build.gradle.kts, settings.gradle.kts, gradle/wrapper/...
```

## USDA API key

The app reads `USDA_API_KEY` from `gradle.properties` into `BuildConfig` at
build time — it is never hard-coded in a `.kt` file. A `DEMO_KEY` placeholder
is included so the project builds out of the box (USDA's public demo key is
heavily rate-limited). Get your own free key at
https://fdc.nal.usda.gov/api-key-signup.html and either:

- put `USDA_API_KEY=your-real-key` in your local (non-committed)
  `local.properties`, or
- edit the value in `gradle.properties` directly on your machine.

**For a real published app**, don't ship any personal API key inside the APK
at all — a determined user can extract it. Instead, run a small backend
(even a single serverless function) that holds the USDA key and proxies the
search request, and point the app at your backend URL instead of USDA's.

## How to build and run

You'll need [Android Studio](https://developer.android.com/studio)
(Koala/2024.1 or newer recommended).

1. **Open the project**: Android Studio → Open → select the `MacroMate`
   folder (the one containing `settings.gradle.kts`).
2. **Sync Gradle**: Android Studio will prompt automatically; otherwise
   File → Sync Project with Gradle Files. First sync downloads Gradle 8.7 and
   all dependencies — needs internet access once.
3. **Run it**: pick a device/emulator (API 24+) from the toolbar dropdown and
   press ▶ Run. First launch creates the Room database and seeds it with the
   starter food list automatically.
4. **Build a debug APK** (without running): Build → Build App Bundle(s) /
   APK(s) → Build APK(s). The APK appears under
   `app/build/outputs/apk/debug/app-debug.apk`.
5. **Build a release APK/AAB later**: Build → Generate Signed Bundle / APK →
   follow the wizard to create (or reuse) a signing keystore. Release builds
   already have `isMinifyEnabled = true` with matching ProGuard rules.

If Gradle sync fails on the very first try, it's almost always a network
hiccup fetching a dependency — click "Try Again" or re-sync.

## Making future changes

The architecture is intentionally modular so you can ask for changes like
the ones in the spec ("change the colour", "add this food", "add Tamil
language", etc.) without a rewrite:

- **New foods** → add a line to `FoodSeedData.kt`.
- **Colors/branding** → `ui/theme/Color.kt` and `Theme.kt`.
- **New screen** → add a `Screen` entry in `ui/navigation/NavGraph.kt`, a
  `composable(...)` block in `MainActivity.kt`, and a new package under `ui/`.
- **New database field** → add the column to the relevant entity in
  `data/local/entity/`, bump the Room `version`, and provide a migration (or,
  during development, use `.fallbackToDestructiveMigration()` temporarily).

## Nutrition accuracy

Every local/seed value is an approximation from typical published nutrition
references — real values vary by brand, recipe, cooking method, and portion.
The app labels its source (`SourceTag` component) rather than presenting
numbers as lab-exact, and the Custom Food / Recipe Builder screens exist
specifically so you can enter your own more-precise numbers for a packaged
product or a home recipe.
